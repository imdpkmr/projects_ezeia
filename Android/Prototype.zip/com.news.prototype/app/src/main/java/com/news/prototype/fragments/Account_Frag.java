package com.news.prototype.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.news.prototype.R;
import com.news.prototype.adapter.GridViewAdapter;
import com.news.prototype.adapter.ListViewAdapter;
import com.news.prototype.adapter.RecyclerViewItem;
import com.news.prototype.models.Team;
import com.news.prototype.sgen;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Account_Frag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Account_Frag extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private RecyclerView listView;
    private RecyclerView gridView;
    private ListViewAdapter listViewAdapter;
    private GridViewAdapter gridViewAdapter;
    private ArrayList<RecyclerViewItem> corporations;
    private ArrayList<RecyclerViewItem> operatingSystems;


    public Account_Frag() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Account_Frag.
     */
    // TODO: Rename and change types and number of parameters
    public static Account_Frag newInstance(String param1, String param2) {
        Account_Frag fragment = new Account_Frag();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_account_, container, false);

        listView = (RecyclerView) v.findViewById(R.id.list);
        gridView = (RecyclerView) v.findViewById(R.id.grid);

        listView.setHasFixedSize(true);
        gridView.setHasFixedSize(true);
        setDummyData();
        @SuppressLint("ResourceType") Animation anim= AnimationUtils.loadAnimation(getContext(), R.animator.cycle);

        //set layout manager and adapter for "ListView"
        LinearLayoutManager horizontalManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        listView.setLayoutManager(horizontalManager);
        listViewAdapter = new ListViewAdapter(getActivity(),corporations);
        listView.setAdapter(listViewAdapter);

        //set layout manager and adapter for "GridView"
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 3);
        gridView.setLayoutManager(layoutManager);
        gridViewAdapter = new GridViewAdapter(getActivity(),operatingSystems,anim);
        gridView.setAdapter(gridViewAdapter);
        return v;
    }

    private void setDummyData() {
        ArrayList<Team> fed = sgen.getdata_fromsql(getContext(), "select '-' AS col1, M_LEVEL AS col2, M_NAME AS col3,M_MODULE3 AS col5, '-' AS col4 from MENUS WHERE TYPE = '';");
        if (fed.size() < 1) {
            Toast.makeText(getContext(), "No Icons Allocated to you in this Module.Please Contact to Your Administrator", Toast.LENGTH_LONG).show();
        }

        corporations = new ArrayList<RecyclerViewItem>();
        for (int i = 0; i < fed.size(); i++) {
            if (fed.get(i).getcol2().trim().equals("0")) {
                corporations.add(new RecyclerViewItem(R.mipmap.ic_launcher_round,fed.get(i).getcol3(), fed.get(i).getcol5().trim().toString()));
            }
        }
        operatingSystems = new ArrayList<RecyclerViewItem>();
        for (int i = 0; i < fed.size(); i++) {
            if (fed.get(i).getcol2().trim().equals("0")) {
                try {
                    operatingSystems.add(new RecyclerViewItem(R.mipmap.ic_launcher_round, fed.get(i).getcol3(), fed.get(i).getcol5().trim().toString()));
                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        }
    }

}
