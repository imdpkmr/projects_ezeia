package com.news.prototype.adapter;

public class RecyclerViewItem {

    private int drawableId;
    private String name;
    private String module3;
    private String module1;
    private String module2;

    public RecyclerViewItem(int drawableId, String name, String module3) {
        this.drawableId = drawableId;
        this.name = name;
        this.module3 = module3;
    }

    public RecyclerViewItem(int drawableId, String name, String module3,String module1){
        this.drawableId = drawableId;
        this.name = name;
        this.module3 = module3;
        this.module1 = module1;
    }

    public int getDrawableId() {
        return drawableId;
    }

    public String getName() {
        return name;
    }

    public String getModule3() {
        return module3;
    }
    public String getModule1() {
        return module1;
    }
    public String getModule2() {
        return module2;
    }

}
