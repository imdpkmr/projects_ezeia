package com.news.prototype.activities_M;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.news.prototype.R;
import com.news.prototype.fragments.Account_Frag;
import com.news.prototype.fragments.Home_Frag;
import com.news.prototype.fragments.Search_Frag;
import com.news.prototype.fragments.ShortList_frag;

import static com.news.prototype.sgen.senderpage;

public class MainLandingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_landing);
        BottomNavigationView navigation = findViewById(R.id.navigation);

        new Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        Fragment fragment = new Home_Frag();
                        getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, fragment, "MainLandingactivity").addToBackStack("null").commit();
                    }
                }, 10);

        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.HomeP:
                        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
                        Fragment fragment = new Home_Frag();
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.content_frame, fragment, senderpage);
                        fragmentTransaction.addToBackStack(senderpage);
                        fragmentTransaction.commit();

//                        startActivity(new Intent(MainActivity.this,MainActivity.class));
//                        overridePendingTransition(R.anim.to_right, R.anim.to_left);
                        return true;
                    case R.id.SearchP:

                        /*getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);// set drawable icon
                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/
                        Fragment fragment1 = new Search_Frag();
                        FragmentManager fragmentManager1 = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
                        fragmentTransaction1.replace(R.id.content_frame, fragment1, senderpage);
                        fragmentTransaction1.addToBackStack(senderpage);
                        fragmentTransaction1.commit();

                        return true;
                    case R.id.ProfileP:
                        /*getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);// set drawable icon
                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/
                        Fragment fragment2 = new Account_Frag();
                        FragmentManager fragmentManager2 = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction2 = fragmentManager2.beginTransaction();
                        fragmentTransaction2.replace(R.id.content_frame, fragment2, senderpage);
                        fragmentTransaction2.addToBackStack(senderpage);
                        fragmentTransaction2.commit();
                        return true;

                    case R.id.ShortListP:
                        /*getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);// set drawable icon
                        getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/
                        Fragment fragment3 = new ShortList_frag();
                        FragmentManager fragmentManager3 = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction3 = fragmentManager3.beginTransaction();
                        fragmentTransaction3.replace(R.id.content_frame, fragment3, senderpage);
                        fragmentTransaction3.addToBackStack(senderpage);
                        fragmentTransaction3.commit();
                        return true;
                }
                return false;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.top_menus, menu);

        return super.onCreateOptionsMenu(menu);
    }

}
